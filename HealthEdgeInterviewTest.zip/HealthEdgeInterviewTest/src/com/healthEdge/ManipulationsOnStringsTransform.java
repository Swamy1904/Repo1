package com.healthEdge;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.logging.Logger;

public class ManipulationsOnStringsTransform {
    private static final Logger LOGGER = Logger.getLogger(ManipulationsOnStringsTransform.class.getName());

    public static void main(String[] args) {
        LOGGER.info("Enter the first String value & Press Enter here.... : ");
        try {
            //Input using BufferReader
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            // Reading data using readLine
            String firstString = reader.readLine();
            String secondString = reader.readLine();
            System.out.println("Entered values: " + firstString + " && " + secondString);
            transformStringToAnother(firstString, secondString);
        } catch (Exception e) {
            LOGGER.info("Exception during the process. " + e.getMessage());
            e.printStackTrace();
        }


    }

    private static void transformStringToAnother(String firstString, String secondString) {
        int firstLen = firstString.length();
        int secondLen = secondString.length();
        /**
         * method to calculate common characters between two strings
         */
        int commonLen = commonLength(firstString, secondString, firstLen, secondLen);

        System.out.println("Minimum no of " + "deletions = " + (firstLen - commonLen));
        System.out.println("Minimum no of " + "insertions = " + (secondLen - commonLen));
        if (firstLen % 2 == 0)
            System.out.println("Minimum no of "
                    + "substitutions = " + (commonLen / 2));
        else
            System.out.println("Minimum no of " + "substitutions = " + (commonLen - 1) / 2);

    }


    private static int commonLength(String firstString, String secondString, int firstLen, int secondLen) {
        int commonLenArr[][] = new int[firstLen + 1][secondLen + 1];      // [m+1, n+1]
        int i, j;
        for (i = 0; i <= firstLen; i++) {                    //0 to m
            for (j = 0; j <= secondLen; j++) {              //0 to n
                if (i == 0 || j == 0)
                    commonLenArr[i][j] = 0;
                else if (firstString.charAt(i - 1)
                        == secondString.charAt(j - 1))
                    commonLenArr[i][j] = commonLenArr[i - 1][j - 1] + 1;
                else
                    commonLenArr[i][j] = Math.max(commonLenArr[i - 1][j],
                            commonLenArr[i][j - 1]);
            }
        }
        return commonLenArr[firstLen][secondLen];
    }


}
